import argparse

parser = argparse.ArgumentParser(description='Generate GCode for bed levelling')
parser.add_argument('width', type=float, help='Max X dimension of bed in mm')
parser.add_argument('height', type=float, help='Max Y dimension of bed in mm')
parser.add_argument('--feedrate', type=float, help='Feedrate, default 150mm/minute', default=150)
parser.add_argument('--diameter', type=float, help='Diameter of tool in mm, default 3mm', default=3)
parser.add_argument('--preview', dest='preview', action='store_true', help='Output only header and up to two cycles of the program')

args = parser.parse_args()

print """
(Units in mm)
G21

(Relative mode)
G91

(Feedrate 150mm/minute)
F%f
""" % args.feedrate

cycle_direction = [1, -1]

xdist = args.width - args.diameter
ydist = args.height - args.diameter

# TODO: Use longest diameter to determine most efficient cycle orientation
cycles = int(xdist / args.diameter)

if args.preview:
	cycles = min(cycles, 2)

for cycle in range(cycles):
	print '(Cycle %d/%d)' % (cycle, cycles)
	print 'G01 Y%f' % (ydist * cycle_direction[cycle % 2])
	print 'G01 X%f' % (args.diameter)
	print

print '(Program end)'
print 'M2'

