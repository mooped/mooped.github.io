require 'cora'
require 'siri_objects'
require 'pp'

class SiriProxy::Plugin::Lightwave < SiriProxy::Plugin
    
  s = UDPSocket.new
  port = 9760
  host = "192.168.0.10"
  rooms = Hash.new
 
  class Room
    def initialize(inSockets, inItems)
      @sockets = inSockets
      @items   = inItems
    end
    attr_accessor :sockets, :items
  end
 
  rooms["sitting room"]=Room.new({ "light" => "R1D1", "lights" => "R1D1", "left socket" => "R1D2", "right socket" => "R1D3" }, {})
  
  rooms["bedroom"]=Room.new({ "light" => "R2D1", "lights" => "R2D1", "left socket" => "R2D2", "right socket" => "R2D3" }, {})

  room=rooms["sitting room"]

  def initialize(config)
    #if you have custom configuration options, process them here!
  end

  listen_for /(I'm|I am) in( the)? ([a-zA-Z ]*)/ do |iam1,the1,roomName|
    if rooms.has_key?(roomName)
      room=rooms[roomName]
      say ("OK, you're in the " + roomName + ".")
    else
      say ("I don't know where the " + roomName + " is.")
    end
    request_completed #always complete your request! Otherwise the phone will "spin" at the user!
  end

  listen_for /([Rr]egister|[Tt]here is|[Tt]here's)( the| a| an| and)? ([a-zA-Z ]*) in( the)? ([A-Za-z ]*)/ do |reg1,the1,item,the2,socket|
    if room.sockets.has_key?(socket)
      room.items.delete_if {|key, value| value == socket }
      room.items[item]=socket
      say ("OK, there's a '" + item + "' in the '" + socket + "'.")
    else
      say ("Sorry, Charlie, I don't know what device a '" + socket + "' is.")
    end
    request_completed #always complete your request! Otherwise the phone will "spin" at the user!
  end
  
  listen_for /([Ss]witch|[Tt]urn)( the| a| an| and)? ([A-Za-z ]*) (on|up)/ do |turn1,the1,item,on1|
    if room.items.has_key?(item)
      say ("Turning '" + item + "' on")
      s.send("000,!" +room.sockets[room.items[item]]+ "F1|" + item + "|On", 0, host, port);
    elsif room.sockets.has_key?(item)
      say ("Turning on '" + item + "'.")
      s.send("000,!" +room.sockets[item]+ "F1|" + item + "|On", 0, host, port);
    else
      say ("Sorry, Charlie, I don't know anything about '" + item + "'.")
    end
    request_completed #always complete your request! Otherwise the phone will "spin" at the user!
  end
  
  listen_for /([Ss]witch|[Tt]urn) (on|up)( the| a| an| and)? ([A-Za-z ]*)/ do |turn1,on1,the1,item|
    if room.items.has_key?(item)
      say ("Turning '" + item + "' on")
      s.send("000,!" +room.sockets[room.items[item]]+ "F1|" + item + "|On", 0, host, port);
    elsif room.sockets.has_key?(item)
      say ("Turning on '" + item + "'.")
      s.send("000,!" +room.sockets[item]+ "F1|" + item + "|On", 0, host, port);
    else
      say ("Sorry, Charlie, I don't know anything about '" + item + "'.")
    end
    request_completed #always complete your request! Otherwise the phone will "spin" at the user!
  end
  
  listen_for /([Ss]witch|[Tt]urn)( the| a| an| and)? ([A-Za-z ]*) (off|down)/ do |turn1,the1,item,off1|
    if room.items.has_key?(item)
      say ("Turning '" + item + "' off")
      s.send("000,!" +room.sockets[room.items[item]]+ "F0|" + item + "|Off", 0, host, port);
    elsif room.sockets.has_key?(item)
      say ("Turning off '" + item + "'.")
      s.send("000,!" +room.sockets[item]+ "F0|" + item + "|Off", 0, host, port);
    else
      say ("Sorry, Charlie, I don't know anything about '" + item + "'.")
    end
    request_completed #always complete your request! Otherwise the phone will "spin" at the user!
  end
  
  listen_for /([Ss]witch|[Tt]urn) (off|down)( the| a| an| and)? ([A-Za-z ]*)/ do |turn1,off1,the1,item|
    if room.items.has_key?(item)
      say ("Turning '" + item + "' off")
      s.send("000,!" +room.sockets[room.items[item]]+ "F0|" + item + "|Off", 0, host, port);
    elsif room.sockets.has_key?(item)
      say ("Turning off '" + item + "'.")
      s.send("000,!" +room.sockets[item]+ "F0|" + item + "|Off", 0, host, port);
    else
      say ("Sorry, Charlie, I don't know anything about '" + item + "'.")
    end
    request_completed #always complete your request! Otherwise the phone will "spin" at the user!
  end
end
