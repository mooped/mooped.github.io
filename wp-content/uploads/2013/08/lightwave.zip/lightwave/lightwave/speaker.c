#include <stdio.h>
#include "speaker.h"

static FILE *s_f=NULL;

void speakerInitialise()
{
  s_f=popen("festival","w");
  //fprintf(s_f, "(voice_cmu_us_awb_arctic_clunits)\n");
}

void speakerSay(const char* text)
{
  fprintf(s_f, "(SayText \"%s\")\n", text);
  fflush(s_f);
}
