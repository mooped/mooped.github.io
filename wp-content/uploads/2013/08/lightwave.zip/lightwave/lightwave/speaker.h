#ifndef __SPEAKER_H__
#define __SPEAKER_H__

void speakerInitialise();
void speakerSay(const char* text);

#endif // __SPEAKER_H__
