#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include "speaker.h"

static int s_recvSock;
static int s_sendSock;

typedef unsigned int u32;

#define ARRAY_SIZEOF(a) (sizeof(a)/sizeof(a[0]))

#define TRUE 1
#define FALSE 0

int netInit(void)
{
	s_recvSock=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if (s_recvSock!=-1)
	{
		int timeout = 1000;
		setsockopt(s_recvSock, SOL_SOCKET, SO_RCVTIMEO,(char*)&timeout,sizeof(timeout));		
		s_sendSock=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
		if (s_sendSock!=-1)
		{
			return TRUE;
		}
	}
	return FALSE;
}

int netBind(u32 port)
{
	if (s_recvSock!=-1)
	{
		struct sockaddr_in address;
		int ret;
		address.sin_family=AF_INET;
		address.sin_port=htons(port);
		address.sin_addr.s_addr=htonl(INADDR_ANY);
		ret=bind(s_recvSock, (struct sockaddr*)&address, sizeof(address));
		if (!ret)
		{
			return TRUE;
		}
	}
	return FALSE;
}

void netClose(void)
{
	if (s_recvSock!=-1)
	{
		close(s_recvSock);
	}
	if (s_sendSock!=-1)
	{
		close(s_sendSock);
	}
}

int netSend(u32 address, u32 port, void *data, u32 size)
{
	if (s_sendSock!=-1)
	{
		struct sockaddr_in to;
		int ret;
		to.sin_family=AF_INET;
		to.sin_port=htons(port);
		to.sin_addr.s_addr=address;
		ret=sendto(s_sendSock, data, size, 0, (struct sockaddr*)&to, sizeof(to));
		if (ret!=-1)
		{
			return ret;
		}
	}
	return FALSE;
}

int netRecieve(u32 *address, u32 *port, void *data, u32 maxSize)
{
	if (s_recvSock!=-1)
	{
		struct sockaddr_in from;
		socklen_t size=sizeof(from);
		int ret=recvfrom(s_recvSock, data, maxSize, 0, (struct sockaddr*)&from, &size);
		*address=from.sin_addr.s_addr;
		*port=htons(from.sin_port);
		return ret;
	}
	return FALSE;
}

#define SEND_STRING "000,!R1D1F0|Hello Charlie|Lights Off"
//#define SEND_STRING "000,!R1D1F1|Hello Charlie|Lights On"
//#define SEND_STRING "533,!R1D1F0|Hello Charlie|Lights Off"

int main2(int argc, char **argv);

int main(int argc, char **argv)
{
	char *args[]={
		"sphinx",
		"-hmm", "/home/pi/hub4wsj_sc_8kadapt",
		"-lm", "/home/pi/lightwave/TAR6859/6859.lm",
		"-dict", "/home/pi/lightwave/TAR6859/6859.dic",
		"-samprate", "16000", 
		"-adcdev", "plughw:1,0"}; 
	if (!netInit())
		printf("Failed to init\n");
	if (!netBind(9761))
		printf("Failed to listen\n");
        speakerInitialise();
	main2(ARRAY_SIZEOF(args), args);
	netClose();
	return 0;
}

int s_messageId=0;

void lightwaveMessage(const char *message)
{
	char buf[1024];
	u32 address=0;
	u32 port=0;
	u32 len;
	int failed=1;
	while (failed)
	{
		sprintf(buf, "%03d,%s", s_messageId, message);
		if (netSend(0x0A00A8C0, 9760, buf, strlen(buf)+1)!=strlen(buf)+1)
			printf("Failed to send\n");
		failed=0;
#if 0
		printf("Listening for reply\n");
		len=netRecieve(&address, &port, buf, sizeof(buf));
		if (len>0)
		{
			buf[len]='\0';
			printf("%08x %04x %s\n", address, port, buf);
		}
		else
		{
			printf("Failed to recv\n");
			failed=1;
		}
#endif
		s_messageId++;
	}
}
