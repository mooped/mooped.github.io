/* -*- c-basic-offset: 4; indent-tabs-mode: nil -*- */
/* ====================================================================
 * Copyright (c) 1999-2010 Carnegie Mellon University.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * This work was supported in part by funding from the Defense Advanced 
 * Research Projects Agency and the National Science Foundation of the 
 * United States of America, and the CMU Sphinx Speech Consortium.
 *
 * THIS SOFTWARE IS PROVIDED BY CARNEGIE MELLON UNIVERSITY ``AS IS'' AND 
 * ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL CARNEGIE MELLON UNIVERSITY
 * NOR ITS EMPLOYEES BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * ====================================================================
 *
 */
/*
 * continuous.c - Simple pocketsphinx command-line application to test
 *                both continuous listening/silence filtering from microphone
 *                and continuous file transcription.
 */

/*
 * This is a simple example of pocketsphinx application that uses continuous listening
 * with silence filtering to automatically segment a continuous stream of audio input
 * into utterances that are then decoded.
 * 
 * Remarks:
 *   - Each utterance is ended when a silence segment of at least 1 sec is recognized.
 *   - Single-threaded implementation for portability.
 *   - Uses audio library; can be replaced with an equivalent custom library.
 */

#include <stdio.h>
#include <string.h>

#if !defined(_WIN32_WCE)
#include <signal.h>
#include <setjmp.h>
#endif
#if defined(WIN32) && !defined(GNUWINCE)
#include <time.h>
#else
#include <sys/types.h>
#include <sys/time.h>
#endif

#include <sphinxbase/err.h>
#include <sphinxbase/ad.h>
#include <sphinxbase/cont_ad.h>

#include <pocketsphinx.h>

#undef DEFAULT_SAMPLES_PER_SEC
#define DEFAULT_SAMPLES_PER_SEC 16000

#define PI

#ifdef PI
#define ROOM				"R1" // Assume pi downstairs
#define LEFT_SOCKET_ON		"aplay leftSocketOn.wav"
#define LEFT_SOCKET_OFF		"aplay leftSocketOff.wav"
#define RIGHT_SOCKET_ON		"aplay rightSocketOn.wav"
#define RIGHT_SOCKET_OFF	"aplay rightSocketOff.wav"
#define LIGHT_ON			"aplay lightsOn.wav"
#define LIGHT_OFF			"aplay lightsOff.wav"
#define LIGHT_25			"aplay lights25.wav"
#define LIGHT_50			"aplay lights50.wav"
#define LIGHT_75			"aplay lights75.wav"
#define GOODBYE				"aplay bye.wav"
#define TELEVISION			"sudo /home/pi/irTrans/irTrans.out && aplay tv.wav"
#else
#define ROOM				"R2" // Assume laptop upstairs
#define LEFT_SOCKET_ON		"say Left socket up"
#define LEFT_SOCKET_OFF		"say Left socket down"
#define RIGHT_SOCKET_ON		"say Right socket up"
#define RIGHT_SOCKET_OFF	"say Right socket down"
#define LIGHT_ON			"say Lights up"
#define LIGHT_OFF			"say Lights down"
#define LIGHT_25			"say Lights 25 percent"
#define LIGHT_50			"say Lights 50 percent"
#define LIGHT_75			"say Lights 75 percent"
#define GOODBYE				"say See you later"
#define TELEVISION			"say Switching TV"
#endif

typedef struct LightWaveCommands_s
{
	const char *vocalCommand;
	const char *serverCommand;
	const char *reply;
} LightWaveCommands;

LightWaveCommands commands[]=
{
	{"JEEVES LEFT SOCKET UP", "!"ROOM"D2F1|Left Socket|On", LEFT_SOCKET_ON},
	{"JEEVES LEFT SOCKET DOWN", "!"ROOM"D2F0|Left Socket|Off", LEFT_SOCKET_OFF},
	{"JEEVES RIGHT SOCKET UP", "!"ROOM"D3F1|Right Socket|On", RIGHT_SOCKET_ON},
	{"JEEVES RIGHT SOCKET DOWN", "!"ROOM"D3F0|Right Socket|Off", RIGHT_SOCKET_OFF},
	{"JEEVES LIGHTS UP", "!"ROOM"D1FdP32|Lounge Light|On", LIGHT_ON},
	{"JEEVES LIGHTS DOWN", "!"ROOM"D1F0|Lounge Light|Off", LIGHT_OFF},
	{"JEEVES LIGHTS TWENTY FIVE", "!"ROOM"D1FdP8|Lounge Light|25%", LIGHT_25},
	{"JEEVES LIGHTS FIFTY", "!"ROOM"D1FdP16|Lounge Light|50%", LIGHT_50},
	{"JEEVES LIGHTS SEVENTY FIVE", "!"ROOM"D1FdP24|Lounge Light|75%", LIGHT_75},
	{"JEEVES BYE BYE", "!"ROOM"D1F0|Lounge Light|Off", GOODBYE},
	{"JEEVES TELEVISION", "", TELEVISION}
};

static const arg_t cont_args_def[] = {
	POCKETSPHINX_OPTIONS,
	/* Argument file. */
	{ "-argfile",
		ARG_STRING,
		NULL,
		"Argument file giving extra arguments." },
	{ "-adcdev", 
		ARG_STRING, 
		NULL, 
		"Name of audio device to use for input." },
	{ "-infile", 
		ARG_STRING, 
		NULL, 
		"Audio file to transcribe." },
	{ "-time", 
		ARG_BOOLEAN, 
		"no", 
		"Print word times in file transcription." },
	CMDLN_EMPTY_OPTION
};

static ps_decoder_t *ps;
static cmd_ln_t *config;
static FILE* rawfd;

void fuzzyTimeOfDay(char *buf)
{
	time_t timeValue;
	time(&timeValue);
	struct tm *pTime=localtime(&timeValue);
	int hour=pTime->tm_hour;
	int minute=pTime->tm_min;
	int seconds=pTime->tm_sec;

	minute=minute+(30+seconds)/60;
	switch (minute%5)
	{
		case 1:
		case 2: strcat(buf, "just gone "); break;
		case 3:
		case 4: strcat(buf, "coming up to "); break;
	}
	switch ((minute+2)/5)
	{
		case 1: strcat(buf, "5 past "); break;
		case 2: strcat(buf, "10 past "); break;
		case 3: strcat(buf, "quarter past "); break;
		case 4: strcat(buf, "20 past "); break;
		case 5: strcat(buf, "25 past "); break;
		case 6: strcat(buf, "half past "); break;
		case 7: strcat(buf, "25 to "); break;
		case 8: strcat(buf, "20 to "); break;
		case 9: strcat(buf, "quarter to "); break;
		case 10: strcat(buf, "10 to "); break;
		case 11: strcat(buf, "5 to "); break;
	}
	if (minute<33)
		hour--;
	hour=(hour%12)+1;
	switch (hour)
	{
		case 1: strcat(buf, "1"); break;
		case 2: strcat(buf, "2"); break;
		case 3: strcat(buf, "3"); break;
		case 4: strcat(buf, "4"); break;
		case 5: strcat(buf, "5"); break;
		case 6: strcat(buf, "6"); break;
		case 7: strcat(buf, "7"); break;
		case 8: strcat(buf, "8"); break;
		case 9: strcat(buf, "9"); break;
		case 10: strcat(buf, "10"); break;
		case 11: strcat(buf, "11"); break;
		case 12: strcat(buf, "12"); break;
	}
	if (minute==0 || minute==60)
	{
		strcat(buf, " o'clock");
	}
	printf("%s\n",buf);
}

	static int32
ad_file_read(ad_rec_t * ad, int16 * buf, int32 max)
{
	size_t nread;

	nread = fread(buf, sizeof(int16), max, rawfd);

	return (nread > 0 ? nread : -1);
}

	static float
print_word_times(int32 start)
{
	float minError=1.0f;
	ps_seg_t *iter = ps_seg_iter(ps, NULL);
	while (iter != NULL) {
		int32 sf, ef, pprob;
		float conf;

		ps_seg_frames (iter, &sf, &ef);
		pprob = ps_seg_prob (iter, NULL, NULL, NULL);
		conf = logmath_exp(ps_get_logmath(ps), pprob);
		if (strncmp(ps_seg_word(iter), "TWENTY", 6)!=0 && conf<minError)
			minError=conf;
		printf ("%s %f %f %f (%d)\n", ps_seg_word (iter), (sf + start) / 100.0, (ef + start) / 100.0, conf, pprob);
		iter = ps_seg_next (iter);
	}
	return minError;
}

/*
 * Continuous recognition from a file
 */
static void
recognize_from_file() {
	cont_ad_t *cont;
	ad_rec_t file_ad = {0};
	int16 adbuf[4096];
	const char* hyp;
	const char* uttid;
	int32 k, ts, start;

	char waveheader[44];
	if ((rawfd = fopen(cmd_ln_str_r(config, "-infile"), "rb")) == NULL) {
		E_FATAL_SYSTEM("Failed to open file '%s' for reading", 
				cmd_ln_str_r(config, "-infile"));
	}

	fread(waveheader, 1, 44, rawfd);

	file_ad.sps = (int32)cmd_ln_float32_r(config, "-samprate");
	file_ad.bps = sizeof(int16);

	if ((cont = cont_ad_init(&file_ad, ad_file_read)) == NULL) {
		E_FATAL("Failed to initialize voice activity detection");
	}
	if (cont_ad_calib(cont) < 0)
		E_FATAL("Failed to calibrate voice activity detection\n");
	rewind (rawfd);

	for (;;) {

		while ((k = cont_ad_read(cont, adbuf, 4096)) == 0);

		if (k < 0) {
			break;
		}

		if (ps_start_utt(ps, NULL) < 0)
			E_FATAL("ps_start_utt() failed\n");

		ps_process_raw(ps, adbuf, k, FALSE, FALSE);

		ts = cont->read_ts;
		start = ((ts - k) * 100.0) / file_ad.sps;

		for (;;) {
			if ((k = cont_ad_read(cont, adbuf, 4096)) < 0)
				break;

			if (k == 0) {
				/*
				 * No speech data available; check current timestamp with most recent
				 * speech to see if more than 1 sec elapsed.  If so, end of utterance.
				 */
				if ((cont->read_ts - ts) > DEFAULT_SAMPLES_PER_SEC)
					break;
			}
			else {
				/* New speech data received; note current timestamp */
				ts = cont->read_ts;
			}


			ps_process_raw(ps, adbuf, k, FALSE, FALSE);
		}

		ps_end_utt(ps);

		if (cmd_ln_boolean_r(config, "-time")) {
			print_word_times(start);
		} else {
			hyp = ps_get_hyp(ps, NULL, &uttid);
			printf("%s: %s\n", uttid, hyp);
		}
		fflush(stdout);	
	}

	cont_ad_close(cont);
	fclose(rawfd);
}

/* Sleep for specified msec */
	static void
sleep_msec(int32 ms)
{
#if (defined(WIN32) && !defined(GNUWINCE)) || defined(_WIN32_WCE)
	Sleep(ms);
#else
	/* ------------------- Unix ------------------ */
	struct timeval tmo;

	tmo.tv_sec = 0;
	tmo.tv_usec = ms * 1000;

	select(0, NULL, NULL, NULL, &tmo);
#endif
}

/*
 * Main utterance processing loop:
 *     for (;;) {
 * 	   wait for start of next utterance;
 * 	   decode utterance until silence of at least 1 sec observed;
 * 	   print utterance result;
 *     }
 */
void lightwaveMessage(const char *message);

	static void
recognize_from_microphone()
{
	ad_rec_t *ad;
	int16 adbuf[4096];
	int32 k, ts, rem, start;
	int delay=0;
	char const *hyp;
	char const *uttid;
	cont_ad_t *cont;
	char word[256];

	if ((ad = ad_open_dev(cmd_ln_str_r(config, "-adcdev"),
					(int)cmd_ln_float32_r(config, "-samprate"))) == NULL)
		E_FATAL("Failed to open audio device\n");

	/* Initialize continuous listening module */
	if ((cont = cont_ad_init(ad, ad_read)) == NULL)
		E_FATAL("Failed to initialize voice activity detection\n");
	if (ad_start_rec(ad) < 0)
		E_FATAL("Failed to start recording\n");
	if (cont_ad_calib(cont) < 0)
		E_FATAL("Failed to calibrate voice activity detection\n");

	for (;;) {
		int bGiveUp=0;
		/* Indicate listening for next utterance */
		if (delay==0)
		{
			printf("READY....\n");
#ifdef PI
			system("gpio -g write 21 0");
			system("gpio -g write 22 1");
#endif
			fflush(stdout);
			fflush(stderr);
		}

		/* Wait data for next utterance */
		while ((k = cont_ad_read(cont, adbuf, 4096)) == 0 || delay)
		{
			if (delay)
			{
				delay--;
				if (delay==0)
				{
					printf("READY....\n");
#ifdef PI
					system("gpio -g write 21 0");
					system("gpio -g write 22 1");
#endif
					fflush(stdout);
					fflush(stderr);
				}
			}
			sleep_msec(10);
		}

#ifdef PI
		system("gpio -g write 22 0");
		system("gpio -g write 17 1");
#endif

		if (k < 0)
			E_FATAL("Failed to read audio\n");

		/*
		 * Non-zero amount of data received; start recognition of new utterance.
		 * NULL argument to uttproc_begin_utt => automatic generation of utterance-id.
		 */
		if (ps_start_utt(ps, NULL) < 0)
			E_FATAL("Failed to start utterance\n");
		ps_process_raw(ps, adbuf, k, FALSE, FALSE);
		printf("Listening...\n");
		fflush(stdout);

		/* Note timestamp for this first block of data */
		ts = cont->read_ts;
		start=ts;

		/* Decode utterance until end (marked by a "long" silence, >1sec) */
		for (;;) {
			/* Read non-silence audio data, if any, from continuous listening module */
			if ((k = cont_ad_read(cont, adbuf, 4096)) < 0)
				E_FATAL("Failed to read audio\n");
			if (k == 0) {
				/*
				 * No speech data available; check current timestamp with most recent
				 * speech to see if more than 1 sec elapsed.  If so, end of utterance.
				 */
				if ((cont->read_ts - ts) > DEFAULT_SAMPLES_PER_SEC/2)
					break;
			}
			else {
				/* New speech data received; note current timestamp */
				ts = cont->read_ts;
			}

			/*
			 * Decode whatever data was read above.
			 */
			if (ts-start<3*DEFAULT_SAMPLES_PER_SEC)
			{
				rem = ps_process_raw(ps, adbuf, k, FALSE, FALSE);
			}
			else
			{
				rem=0;
				bGiveUp=1;
			}

			/* If no work to be done, sleep a bit */
			if ((rem == 0) && (k == 0))
				sleep_msec(20);
		}

		/*
		 * Utterance ended; flush any accumulated, unprocessed A/D data and stop
		 * listening until current utterance completely decoded
		 */
		ad_stop_rec(ad);
		while (ad_read(ad, adbuf, 4096) >= 0);
		cont_ad_reset(cont);

#ifdef PI
		system("gpio -g write 17 0");
		system("gpio -g write 21 1");
#endif

		printf("Stopped listening, please wait...\n");
		fflush(stdout);
		/* Finish decoding, obtain and print result */
		ps_end_utt(ps);
		if (print_word_times(0)>0.7f)
		{
			hyp = ps_get_hyp(ps, NULL, &uttid);
			printf("%s: %s\n", uttid, hyp);
			fflush(stdout);
			if (!bGiveUp)
			{
				if (hyp)
				{
					int i;
					if (strcmp(hyp, "JEEVES SPEAK TIME")==0)
					{
						char buf[1024];
                                                buf[0]='\0';
						fuzzyTimeOfDay(buf);
						speakerSay(buf);
						delay=450;
					}
					else
					{
						for (i=0; i<sizeof(commands)/sizeof(commands[0]); i++)
						{
							if (strcmp(commands[i].vocalCommand, hyp)==0)
							{
								if (commands[i].serverCommand[0]!='\0')
									lightwaveMessage(commands[i].serverCommand);
								system(commands[i].reply);
								delay=150;
								break;
							}
						}
					}
				}
			}
		}

		/* Resume A/D recording for next utterance */
		if (ad_start_rec(ad) < 0)
			E_FATAL("Failed to start recording\n");
	}

	cont_ad_close(cont);
	ad_close(ad);
}

static jmp_buf jbuf;
	static void
sighandler(int signo)
{
	longjmp(jbuf, 1);
}

	int
main2(int argc, char *argv[])
{
	char const *cfg;

#ifdef PI
	system("gpio -g mode 17 out");
	system("gpio -g mode 21 out");
	system("gpio -g mode 22 out");
	system("gpio -g write 17 0");
	system("gpio -g write 22 0");
	system("gpio -g write 21 0");
#endif
	if (argc == 2) {
		config = cmd_ln_parse_file_r(NULL, cont_args_def, argv[1], TRUE);
	}
	else {
		config = cmd_ln_parse_r(NULL, cont_args_def, argc, argv, FALSE);
	}
	/* Handle argument file as -argfile. */
	if (config && (cfg = cmd_ln_str_r(config, "-argfile")) != NULL) {
		config = cmd_ln_parse_file_r(config, cont_args_def, cfg, FALSE);
	}
	if (config == NULL)
		return 1;

	ps = ps_init(config);
	if (ps == NULL)
		return 1;

	E_INFO("%s COMPILED ON: %s, AT: %s\n\n", argv[0], __DATE__, __TIME__);

	if (cmd_ln_str_r(config, "-infile") != NULL) {
		recognize_from_file();
	} else {

		/* Make sure we exit cleanly (needed for profiling among other things) */
		/* Signals seem to be broken in arm-wince-pe. */
#if !defined(GNUWINCE) && !defined(_WIN32_WCE) && !defined(__SYMBIAN32__)
		signal(SIGINT, &sighandler);
#endif

		if (setjmp(jbuf) == 0) {
			recognize_from_microphone();
		}
	}

	ps_free(ps);
	return 0;
}
