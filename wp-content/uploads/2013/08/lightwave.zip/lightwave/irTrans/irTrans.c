#include <wiringPi.h>

#define IR_PIN 7
#define MODULATION_FREQ 38000

#define SAMSUNG_HDR_MARK 4150 //4500
#define SAMSUNG_HDR_SPACE 4500
#define SAMSUNG_BIT_MARK 200 //560
#define SAMSUNG_ONE_SPACE 1600
#define SAMSUNG_ZERO_SPACE 600

#define POWER_CODE 0xE0E040BF

void sendCode(unsigned int code)
{
  int i;
  pinMode(IR_PIN, GPIO_CLOCK);
  delayMicroseconds(SAMSUNG_HDR_MARK);
  pinMode(IR_PIN, OUTPUT);
  delayMicroseconds(SAMSUNG_HDR_SPACE);
  for (i=0; i<32; i++)
  {
    pinMode(IR_PIN, GPIO_CLOCK);
    delayMicroseconds(SAMSUNG_BIT_MARK);
    pinMode(IR_PIN, OUTPUT);
    delayMicroseconds((code&0x80000000)?SAMSUNG_ONE_SPACE:SAMSUNG_ZERO_SPACE);
    code<<=1;
  }
  pinMode(IR_PIN, GPIO_CLOCK);
  delayMicroseconds(SAMSUNG_BIT_MARK);
  pinMode(IR_PIN, OUTPUT);
}

int main ()
{
  int i;
  wiringPiSetup();
  gpioClockSet(IR_PIN, MODULATION_FREQ);
  pinMode(IR_PIN, OUTPUT);
  digitalWrite(IR_PIN, LOW);
  for (i=0; i<4; i++)
  {
    sendCode(POWER_CODE);
    delay(70);
  }
  pinMode(IR_PIN, OUTPUT);
  return 0; 
}
